Esta carpeta contiene las corridas de prueba en 
NetBSD con el emulador GXemul.